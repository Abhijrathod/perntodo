const express = require('express');
const { Pool } = require('pg');

const app = express();

const pool = new Pool({
  user: 'abhij',
  host: 'localhost',
  database: 'abhij_db',
  password: '9075',
  port: 5432,
});

// Your routes and other server configurations go here
app.listen(3002, () => {
  console.log('Server is running on port 3002');
});